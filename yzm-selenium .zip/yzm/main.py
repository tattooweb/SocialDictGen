import sys
from yzm import picture
print(picture(sys.argv[1:][0])[0])