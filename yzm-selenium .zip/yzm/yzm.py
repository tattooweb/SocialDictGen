import re
import base64
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.ocr.v20181119 import ocr_client, models
from PIL import Image
from selenium import webdriver
secret_id = "AKIDqVGjv18Yw6UeZDuCdnDPN3Sjo31ikt62"
secret_key = "w50lFPK1RSr21B6sPgLxKQhhRu62A3f1"

def picture(pictureurl):
  url = pictureurl
  # url = 'http://www.isaipu.net/manage/login'
  driver = webdriver.Chrome()
  driver.maximize_window()  # 将浏览器最大化
  driver.get(url)
  # 截取当前网页并放到D盘下命名为printscreen，该网页有我们需要的验证码

  driver.save_screenshot('./img/printscreen.png')
  imgelement = driver.find_element_by_id('captchaImage')  # 定位验证码
  location = imgelement.location  # 获取验证码x,y轴坐标
  size = imgelement.size  # 获取验证码的长宽
  rangle = (int(location['x']+880), int(location['y']+350), int(location['x'] + size['width']+970),
            int(location['y'] + size['height']+365))  # 写成我们需要截取的位置坐标
  i = Image.open("./img/printscreen.png")  # 打开截图
  frame4 = i.crop(rangle)  # 使用Image的crop函数，从截图中再次截取我们需要的区域
  frame4=frame4.convert('RGB')
  frame4.save('./img/save.jpg') # 保存我们接下来的验证码图片 进行打码
  driver.close()
  try:
    with open("./img/save.jpg", 'rb') as f:
        img_data = f.read()
    img_base64 = base64.b64encode(img_data)
    params = '{"ImageBase64":"' + str(img_base64, 'utf-8') + '"}'

    cred = credential.Credential(secret_id, secret_key)
    httpProfile = HttpProfile()
    httpProfile.endpoint = "ocr.tencentcloudapi.com"

    clientProfile = ClientProfile()
    clientProfile.httpProfile = httpProfile

    client = ocr_client.OcrClient(cred, "ap-guangzhou", clientProfile)

    req = models.GeneralBasicOCRRequest()
    req.from_json_string(params)
    resp = client.GeneralBasicOCR(req).to_json_string()
    # print(resp)
    ret_list = re.findall( r'"DetectedText": "(.*?)"', resp)
    return ret_list

  except TencentCloudSDKException as err:
      print(err)
      return -1, []