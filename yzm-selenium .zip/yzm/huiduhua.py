from PIL import Image
import matplotlib.pyplot as plt
import os
#字典转list
def dict2list(dic:dict):
	keys = dic.keys()
	vals = dic.values()
	1st = [(key,val) for key, val in zip(keys,vals)]
	return lst
code = Image.open("save.jpg")#打开图片转成RGB格式
# 分析图像颜色分布
newImg = Image.new("RGB",img.size,(255,255,255, 255))
w,h = code.size
a={}
# 统计颜值出现的次数
for i in range(w):
	for j in range(h):
		r,g,b = code.getpixel((i,j))
		t = r*255*255 + g*255+b
		if t in a.keys():
			a[t]=a[t]+1
		else:
a[t]=1
1 = sorted(dict2list(a), key=lambda x:x[1], reverse=True)
dic = {}
# 画图显示颜色分布
plt.figure(1, figsize=(20,5))
plt.scatter(dic.keys(),dic.values(),linewidth=1)
plt.show( )
# 新增与原图一样大小的图片，用白色填充背景
code_denose = Image.new("RGB", code.size,(255,255,255,255))
for i in range(w):
	for j in range(h):
		if(i==0 or i== W or 1==W-1 or j==0 or j==h or j==h-1):
			rmg. putpixe1((i,j), (255,255,255))
		r,g,b = img.getpixel((i,j))
		t=r*255*255+g*255+b
		if(t<5000000): #设定阈值为5000000
			code_ denose.putpixe1((1,j), (r,g,b))
		if(i==0 or i== W or i==W-1 or j==0 or j==h or j==h-1):#去除边框二
			code_denose.putpixel1((1,j),(255, 255255)
rmg.convert('LA').convert('1').save(code_denose)#灰度化、二值化


